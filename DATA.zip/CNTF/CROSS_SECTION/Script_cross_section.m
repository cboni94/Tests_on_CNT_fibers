clear 
close all
clc
%==========================================================================
% PLOT
%==========================================================================
set(0,'defaultTextInterpreter','latex');
% Imposta dimensione font a 16
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);
% Usa LaTeX come interpreter per tutti gli elementi grafici
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');
%-----------------------------------------------------------------------%
%                  CALCOLO RIGIDEZZA TREFOLO MULTILAYER                 %
%-----------------------------------------------------------------------%
% DATI MODELLO
dH = linspace(0,6,1000);   %allungamento fibra
layers = 20;                %n. di layers in cui suddivido la sezione della fibra
ni = 0;                     %poisson coefficient
H = 150;                    %lunghezza iniziale fibrille parallele (altezza iniziale fibra) [mm]
Df = 0.0238;                %diametro fibra [mm]
Rf = Df/2;                  %raggio fibra [mm]
Af = pi*Df^2/4;             %area fibra [mm^2]
% R = Rf/sqrt(pi*layers*(layers+1)+1)

R = Rf/(2*layers+1);        %raggio interno [mm]
D = R*2;                    %diametro fibrilla [mm]
disp(['Diametro fibrilla = ',num2str(D),' mm'])


for n = 0  %n. giri di torsione 400%
    phi = 2*pi*n;               %angolo di torsione [rad]
    phiG = phi*180/pi;          %angolo di torsione [deg]
    theta = phi/H;              %angolo unitario di torsione [rad/mm]
    thetaG = theta*180/pi;        %angolo unitario di torsione [deg/mm]
    disp(['angolo unitario di torsione = ',num2str(thetaG),' deg/mm'])
    
    % PLOT DELLA SEZIONE
    figure('Units','centimeters','position',[10,10,10,10])
    ax = axes();
    hold(ax,'on')
    r = zeros(1,layers);
    m = zeros(1,layers);
    alpha = zeros(1,layers);
    alphaG = zeros(1,layers);
    tet = linspace(0, 2*pi, 40);                %angolo circonferenza (profilo del filo)
    plot(ax,R*cos(tet)*1e3,R*sin(tet)*1e3,Color='#808080',LineWidth=1) %centrale
    % plot(ax,Df/2*cos(tet)*1e3,Df/2*sin(tet)*1e3,Color='#808080',LineWidth=1) 

    for lr=1:layers
        r(lr) = 2*lr*R;
        m(lr) = floor(round(pi/asin(1/(2*lr)),1));  %numero fili avvolti  floor(pi*r(lr)/R);
        alpha(lr) = atan(H/(2*pi*r(lr)*n));         %angolo elica rad 
        alphaG(lr) = alpha(lr)*180/pi;              %angolo elica deg
        %plot Cross Section
        b = r(lr)*tan(alpha(lr));                   %passo elica
        for ii=0:2*pi/m(lr):2*pi-2*pi/m(lr)         %serve per fare m numero di fili
            sezX = zeros(size(tet));                %Sezione
            sezY = zeros(size(tet));
            tk = (-(r(lr)*R*sin(tet))/sqrt(b^2 + r(lr)^2))/b + ii;
            for k=1:length(tet)
                sezX(k) = r(lr)*cos(tk(k)) - R*cos(tk(k)).*cos(tet(k)) + (b*R*sin(tk(k)).*sin(tet(k)))./sqrt(b^2 + r(lr)^2);
                sezY(k) = r(lr)*sin(tk(k)) - R*cos(tet(k)).*sin(tk(k)) - (b*R*cos(tk(k)).*sin(tet(k)))./sqrt(b^2 + r(lr)^2);
            end
            plot(ax,sezX*1e3,sezY*1e3,Color='#808080',LineWidth=1)  %proiezione
        end
    end
    axis("equal");
    xlabel(ax,'$x$ ($\mu$m)')
    ylabel(ax,'$y$ ($\mu$m)')
    box(ax,'on')
    grid(ax,'off')
    xlim(ax,[-1.05*Df/2*1e3 1.05*Df/2*1e3])
    ylim(ax,[-1.05*Df/2*1e3 1.05*Df/2*1e3])
    xticks(ax,[-10 -5 0 5 10])
    % axis("off")
    exportgraphics(gcf,sprintf("section.pdf"),'BackgroundColor','white','ContentType','vector')

    % CALCOLO LUNGHEZZE DOPO RILASSAMENTO FIBRA
    l_last_layer = H;          %lunghezza ridotta filo avvolto [mm]
    %Quindi la nuova altezza della fibra è:
    H_new = sqrt(l_last_layer^2-(2*pi*r(end)*n)^2);  %lunghezza ridotta fibra[mm] =H_in*sqrt(1-cot(alpha(end))^2)
    alpha_max = atan(H_new/(2*pi*Rf*n));%angolo elica superficiale rad 
    alphaG_max = alpha_max*180/pi;      %angolo elica superficiale deg
    disp(['angolo elica superficiale = ',num2str(alphaG_max),' deg'])
end
 

    







