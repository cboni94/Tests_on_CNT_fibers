close all
clear
clc
%==========================================================================
% PLOT fitting stress-strain response of CNT fibers
%==========================================================================

% Set LaTeX as default interpreter for text
set(0,'defaultTextInterpreter','latex');

% Set default font sizes
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);

% Use LaTeX as interpreter for all graphical elements
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');

format long

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                Data preparation               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

H0 = 150;                    % reference gauge length [mm]
D = 6.548254472675135e-04;   % fibril diameter [mm]
A = pi*D^2/4;                 % fibril cross-sectional area [mm^2]

Gauge_Length = 150;           % fiber gauge length [mm]
Diameter = 0.0238;            % fiber diameter [mm]
Section = (pi*Diameter^2)/4;  % fiber cross-sectional area [mm^2]

% Get a structure with all TXT files in the current folder
txtFiles = dir('*.txt');

% Read data from TXT files if available
if ~isempty(txtFiles)
    number_of_files = length(txtFiles);
    name = strings(number_of_files,1);
    
    % Select tests to be plotted
    selected_tests = 1:number_of_files;
    
    figure('Units','centimeters','position',[10,10,8,5.8])   
    hold("on")
    
    k=0;
    all_strain = [];
    all_stress = [];
    x_lim = [];
    y_lim = [];
    
    % Loop through selected test files
    for i = selected_tests
        filename = txtFiles(i).name;
        name(i) = convertCharsToStrings(filename(1:end-4));
        
        % Read data (skip first 3 header rows)
        t = readtable(sprintf("%s.txt",name(i)), ...
                      "Range","A4:E100000", ...
                      "VariableNamingRule","preserve", ...
                      "FileType","delimitedtext");
        
        % Extract force (100 N load cell, channel CH2) and displacement
        Force = t((2:end),end-1).Variables;  
        Stroke = t((2:end),end).Variables;
        
        % Apply smoothing
        windowSize = 10;                        
        Force_smooth = movmean(Force, windowSize);
        
        % Remove initial offset
        Force = Force_smooth - Force_smooth(1);
        
        % Trim data up to maximum force
        imax = find(Force==max(Force));
        Force = Force(1:imax);
        Stroke = Stroke(1:imax);
        
        % Re-align baseline at last near-zero force point
        zeri = find(Force<0.004);
        z = zeri(end);
        Force = Force(z:end)-Force(z);
        Stroke = Stroke(z:imax)-Stroke(z); 
        
        % Compute stress and strain
        strain = Stroke/Gauge_Length;
        stress = Force/Section;
        
        % Store limits for later fitting
        x_lim = [x_lim, strain(end)];
        y_lim = [y_lim, stress(end)];
        
        % Collect stress-strain data
        all_strain = [all_strain; strain(2:end)];
        all_stress = [all_stress; stress(2:end)];
        
        k=k+1;
        disp(filename)
        
        % Plot experimental stress-strain curve
        plot(strain*H0, stress*A*1e3, ...
             "Color",[119,172,48]/255, ...
             'DisplayName', filename(6:7), ...
             "LineWidth",2) 
    end

    % =====================================================================
    % Fit data with polynomial models and define limit point
    % =====================================================================
    
    strain_point = mean(x_lim);  % chosen limit point (strain)
    disp(['Experimental input strain limit = ', num2str(strain_point,16)])
    disp(['Experimental input stroke limit = ', num2str(strain_point*H0,16)])
    
    x_end = 0.04;
    x_fit = linspace(0, x_end, 1000);
    
    % Global fit with constraints
    [pp0, gof0] = fit(all_strain, all_stress, 'poly3', ...
                      'Robust','LAR', ...
                      ConstraintPoints=[0 0]); 
    
    stress_point = pp0(strain_point);
    
    % Different constraint sets for testing
    con ={[0 0;strain_point stress_point], ...
          [0 0;strain_point stress_point;x_end 2200], ...
          [0 0;strain_point stress_point;x_end 1500]};
    
    pp = cell(1, length(con));
    gof = cell(1, length(con));
    
    for c = 1:length(con)
        [pp{c}, gof{c}] = fit(all_strain, all_stress,'poly3', ...
                              'Robust','LAR', ...
                              ConstraintPoints=con{c}); 
        y_fit = pp{c}(x_fit);
    end

    % =====================================================================
    % Model projection and piecewise definitions
    % =====================================================================
    
    strain_lay = x_fit;
    stress_lim = pp{1}(strain_point);
    strain_lin0 = strain_point - 0.0001;
    stress_lin0 = pp{1}(strain_lin0);
    
    % Linear extension from the limit point
    lin = polyfit([strain_lin0 strain_point],[stress_lin0 stress_lim],1);
    
    % Initialize arrays
    base = NaN(size(strain_lay));
    sf = NaN(size(strain_lay));
    sf_0 = NaN(size(strain_lay));
    sf_plateau = NaN(size(strain_lay));
    sf_linear = NaN(size(strain_lay));
    sf_pol_1 = NaN(size(strain_lay));
    sf_pol_2 = NaN(size(strain_lay));
    sf_pol_3 = NaN(size(strain_lay));
    
    % Compute piecewise stress projections
    for i=1:length(strain_lay)
        if strain_lay(i) > 0
            base(i)       = pp0(strain_lay(i));
            sf(i)         = pp{1}(strain_lay(i));
            sf_0(i)       = sf(i);
            sf_plateau(i) = sf(i);
            sf_linear(i)  = sf(i);
            sf_pol_1(i)   = sf(i);
            sf_pol_2(i)   = sf(i);
            sf_pol_3(i)   = sf(i);
            
            if strain_lay(i) > strain_point
                sf(i)         = NaN;
                sf_0(i)       = 0;
                sf_plateau(i) = stress_lim;
                sf_linear(i)  = polyval(lin, strain_lay(i));
                sf_pol_1(i)   = pp{1}(strain_lay(i));
                sf_pol_2(i)   = pp{2}(strain_lay(i));
                sf_pol_3(i)   = pp{3}(strain_lay(i));
            end
        else
            sf(i) = 0;
        end
    end
    
    % =====================================================================
    % Plot final models
    % =====================================================================
    plot(strain_lay*H0, A*sf_linear*1e3,'k:','DisplayName','linear', ...
         'MarkerIndices',1:20:length(strain_lay), LineWidth=1) 
    plot(strain_lay*H0, A*sf_pol_2*1e3,'k-.','DisplayName','poly3', ...
         'MarkerIndices',1:20:length(strain_lay), LineWidth=1) 
    plot(strain_lay*H0, A*sf_plateau*1e3,'k--','DisplayName','plateau', ...
         'MarkerIndices',1:20:length(strain_lay), LineWidth=1) 
    plot(strain_lay*H0, A*sf_0*1e3,'k-','DisplayName','failure', ...
         'MarkerIndices',1:20:length(strain_lay), LineWidth=1) 
    
    % Axes formatting
    xlabel('$\delta L_{i}$ (mm)')
    ylabel('$F_{i}$ (mN)')
    box('on')
    grid('off')
    xlim([0, 5])
    ylim([0, 0.8])
    xticks([0 1 2 3 4 5])
    
    % Legend
    lg = legend('experiment','','','','','','','','linear','polynomial','plateau','failure', ...
                'Location',[0.1,0.6,0.35,0.32],'Box','off');
    set(lg, 'ItemTokenSize', [17, 10]);  
    exportgraphics(gcf,sprintf("figure_fitting.pdf"),'BackgroundColor','white')
    save('pol.mat',"pp")
else
    disp('No TXT files found in the current folder.');
end
