close all
clear
clc
%==========================================================================
% MODEL for twisted CNT fibers - stress-strain response
%==========================================================================

% Default formatting for LaTeX plots
set(0,'defaultTextInterpreter','latex');
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');

% MODEL INPUT CASES
scelta = [1 5 2 4 3];   
% 1 = experimental limit, 2 = best polynomial fit,
% 3 = failure, 4 = plateau, 5 = linear

load("pol.mat")            % polynomial fits from FITTING
s_limit = 0.01730953;      % experimental strain limit from FITTING

% GEOMETRICAL PARAMETERS
dH = linspace(0,6,1000);   % fiber elongation range [mm]
layers = 20;               % number of fibril layers
H = 150;                   % initial fibril length = fiber length [mm]

Df = 0.0238;               % fiber diameter [mm]
Rf = Df/2;                 % fiber radius [mm]
Af = pi*Df^2/4;            % fiber cross-sectional area [mm^2]

R = Rf/(2*layers+1);       % fibril radius [mm]
D = 2*R;                   % fibril diameter [mm]
disp(['Fibril diameter = ',num2str(D),' mm'])

% IMPORT EXPERIMENTAL DATA
xlsxFiles = dir('*.xlsx');
for i = 1:length(xlsxFiles)
    files = xlsxFiles(i).name;
    disp([num2str(i),' ',files([5:6,15:24])])  % display test index and part of filename
end
selected_tests = 1:length(xlsxFiles); 
                 
% LOOP OVER DIFFERENT TWIST LEVELS
for n = [200 400 600]  % number of twist turns
    figure('Units','centimeters','position',[10,10,8,5.8])
    ax = axes();
    hold(ax,'on')

    phi   = 2*pi*n;         % total twist angle [rad]
    theta = phi/H;              % unit twist angle [rad/mm]
    disp(['unit twist angle = ',num2str(theta),' rad/mm'])

    r = zeros(1,layers);      % fibril radii
    m = zeros(1,layers);      % number of fibrils per layer
    alpha = zeros(1,layers);  % helix angles [rad]
    alphaG = zeros(1,layers); % helix angles [deg]

    for lr=1:layers
        r(lr) = 2*lr*R;
        m(lr) = floor(round(pi/asin(1/(2*lr)),1));  % number of fibrils in layer
        alpha(lr) = atan(H/(2*pi*r(lr)*n));         % helix angle [rad]
        alphaG(lr) = alpha(lr)*180/pi;              % helix angle [deg]
    end

    % FIBER RELAXATION (shortening to keep zero force at grips)
    l_last_layer = H; % assume last layer keeps initial length
    H_new = sqrt(l_last_layer^2-(2*pi*r(end)*n)^2);  % relaxed fiber length [mm]
    alpha_max = atan(H_new/(2*pi*Rf*n));             % surface helix angle [rad]
    alphaG_max = alpha_max*180/pi;                   % [deg]
    disp(['Surface helix angle = ',num2str(alphaG_max),' deg'])

    % POLYNOMIAL PROCESSING (from single fiber input)
    for i = 1:length(pp)
        coeff = coeffvalues(pp{i});
        for j = 1:length(coeff)
            pol(i,j) = Af/(sum(m)+1)*coeff(j)/((H)^(length(coeff)-j));
        end
    end
    pol(2,:) = 1.0e-03 * [0.0013 -0.0384 0.3067 0]; % fitted polynomial

    stroke_lim = H_new*s_limit;         % strain limit displacement
    force_lim = polyval(pol(2,:),stroke_lim);
    stroke_linear0 = stroke_lim+0.01;
    force_linear0 = polyval(pol(2,:),stroke_linear0);
    lin = polyfit([stroke_linear0 stroke_lim],[force_linear0 force_lim],1);

    % FIBRIL ELONGATION CALCULATION
    stroke = zeros(length(dH),layers);
    alphaP = zeros(length(dH),layers);
    stroke0 = dH+H_new-H;   % corrected displacement
    for lr=1:layers
        for i=1:length(dH)                   
            alphaP(i,lr) = atan((dH(i)+H_new)/(2*pi*r(lr)*n));
            stroke(i,lr) = sqrt((dH(i)+H_new)^2+(2*pi*r(lr)*n)^2)-H;
        end 
    end
    alphaPG = alphaP*180/pi;   % deformed helix angle [deg]

    % STORAGE VECTORS
    sf = NaN(size(dH)); sf_0 = NaN(size(dH));
    sf_plateau = NaN(size(dH)); sf_linear = NaN(size(dH));
    sf_pol_1 = NaN(size(dH)); sf_pol_2 = NaN(size(dH)); sf_pol_3 = NaN(size(dH));

    % MODEL CURVES
    for input = scelta
        % Central fibril force
        force0 = zeros(length(dH),1);
        for i=1:length(stroke0)
            if stroke0(i)>0
                force0(i) = polyval(pol(2,:),stroke0(i));
                if stroke0(i)>stroke_lim
                    switch input
                        case 1, force0(i) = NaN;             % experimental limit
                        case 2, force0(i) = polyval(pol(2,:),stroke0(i)); % poly fit
                        case 3, force0(i) = 0;               % failure
                        case 4, force0(i) = force_lim;       % plateau
                        case 5, force0(i) = polyval(lin,stroke0(i)); % linear
                    end
                end
            else
                force0(i) = 0;
            end
        end

        % Fibril forces in each layer
        force = zeros(length(dH),layers);
        for lr=1:layers
            for i=1:length(stroke)
                if stroke(i,lr)>0
                    force(i,lr) = polyval(pol(2,:),stroke(i,lr));
                    if stroke(i,lr)>stroke_lim
                        switch input
                            case 1, force(i,lr) = NaN;   linea = '-';  inp = 'limit';
                            case 2, force(i,lr) = polyval(pol(2,:),stroke(i,lr)); linea = '-.'; inp = 'poly';
                            case 3, force(i,lr) = 0;     linea = '-';  inp = 'failure';
                            case 4, force(i,lr) = force_lim; linea = '--'; inp = 'plateau';
                            case 5, force(i,lr) = polyval(lin,stroke(i,lr)); linea = ':'; inp = 'linear';
                        end
                    end
                else
                    force(i,lr) = 0;
                end
            end
        end

        % TOTAL FIBER FORCE
        F0 = force0;                  % central fibril
        F = force.*sin(alphaP);       % helical fibrils
        F_TOT = F0;
        for lr=1:layers
            F_TOT = F_TOT + m(lr).*F(:,lr);
        end        
        stress_mod = F_TOT/Af;
        strain_mod = dH/H_new;

        % Model curve plotting
        plot(ax,strain_mod*100,stress_mod*1e-3,linea,"Color",'k','MarkerIndices', 1:50:length(strain_mod),LineWidth=1) 
    end

    % EXPERIMENTAL DATA PLOT
    for j=selected_tests
        filename = xlsxFiles(j).name;
        giri = str2double(convertCharsToStrings(filename(22:end-10)));
        if giri == n
            test = readmatrix(filename);      
            stroke_test = test(:,1);          % axial displacement [mm]
            force_test = test(:,2);           % axial force [N]
            stress_test = force_test / Af;    % stress [MPa]
            strain_test = stroke_test / H_new; % strain [-]
            % Experimental stress-strain curve
            pl = plot(ax,strain_test*100,stress_test*1e-3,"Color",[119,172,48]/255,LineWidth=2);
            uistack(pl,"bottom")
        end
    end

    % FIGURE FORMATTING
    title(ax,['$\tau$ = ',sprintf('%0.1f',theta),' rad/mm'],'FontSize',8)
    xlabel('$\varepsilon_f$ (\%)')
    ylabel('$\sigma_f$ (GPa)')
    lg = legend(ax,'experiment','','','','linear','polynomial','plateau','failure','','Location',[0.1,0.6,0.35,0.32],'Box','off');
    set(lg,'ItemTokenSize',[17,10]);  
    box(ax,'on'); grid(ax,'off')
    ylim(ax,[0, 2.5]); xlim(ax,[0, 4])
    xticks([0 1 2 3 4])
    exportgraphics(gcf,sprintf("figure_model_%0.1f.pdf",theta),'BackgroundColor','white')    
end
