clear
close all
clc
%==========================================================================
% PLOT Figure 2: tensile response of CNT fibers
%==========================================================================

% Default LaTeX formatting for plots
set(0,'defaultTextInterpreter','latex');
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');

% MODEL PARAMETERS
H = 150;                    % initial fiber length (parallel fibrils) [mm]
Df = 0.0238;                % fiber diameter [mm]
Af = pi*Df^2/4;             % fiber cross-sectional area [mm^2]

% IMPORT EXPERIMENTAL DATA
xlsxFiles = dir('*.xlsx');
for i = 1:length(xlsxFiles)
    files = xlsxFiles(i).name;
    disp([num2str(i),' ',files([5:6,15:24])])  % display test index and part of filename
end

% Select which test files to plot
selected_tests = 1:length(xlsxFiles); 
figure('Units','centimeters','position',[10,10,8,5.8])
ax = axes();
hold(ax,'on')

k=0;
for n = [000 200 400 600]   % number of applied twists (turns)
    k = k+1;
    % Assign color by twist level
    if     n == 300,  col = [ 68,166,219]/255; colm = col*0.5; % light blue
    elseif n == 000,  col = [0.0000  0.4470  0.7410]; colm = col*0.5; % blue
    elseif n == 200,  col = [0.8500  0.3250  0.0980]; colm = col*0.5; % orange
    elseif n == 400,  col = [0.9290  0.6940  0.1250]; colm = col*0.5; % yellow
    elseif n == 600,  col = [0.4940  0.1840  0.5560]; colm = col*0.5; % violet
    elseif n == 500,  col = [255,  0,  0]/255; colm = col*0.5; % red
    elseif n == 700,  col = [162, 20, 47]/255; colm = col*0.5; % dark red
    elseif n == 100,  col = [ 20, 80,200]/255; colm = col*0.5; % custom blue
    else,             col = [255,  0,255]/255; colm = col*0.5; % magenta
    end

    % Twist parameters
    phi = 2*pi*n;               % total twist angle [rad]
    theta = phi/H;              % unit twist angle [rad/mm]
    disp(['unit twist angle = ',num2str(theta),' rad/mm'])

    % Corrected fiber length after twisting
    H_new = sqrt(H^2 - (pi*Df*n)^2);

    % Import and plot selected experimental tests for this twist level
    for j = selected_tests
        filename = xlsxFiles(j).name;
        giri = str2double(convertCharsToStrings(filename(22:end-10)));
        if giri == n
            test = readmatrix(filename);      
            stroke_test = test(:,1);          % axial displacement [mm]
            force_test = test(:,2);           % axial force [N]
            stress_test = force_test / Af;    % stress [MPa]
            strain_test = stroke_test / H_new; % strain [-]
            % Experimental stress-strain curve
            plot(ax, strain_test*100, stress_test*1e-3, ...
                 "Color", col, ...
                 'DisplayName',['$\tau$ = ',sprintf('%0.1f',theta),' rad/mm'], ...
                 LineWidth=1)
        end
    end
    lg{k} = ['$\tau$ = ',sprintf('%0.1f',theta),' rad/mm\qquad'];
end

% Axes formatting
xlabel('$\varepsilon_f$ (\%)')
ylabel('$\sigma_f$ (GPa)')
lg = legend(ax,lg{1},'','',lg{2},'','',lg{3},'','',lg{4},'','','Location','nw','Box','off');
lg.NumColumns = 2;
set(lg, 'ItemTokenSize', [12, 10]);  % [width, height] in points
box(ax,'on')
grid(ax,'off')
xlim(ax,[0, 4])
ylim(ax,[0, 2.5])
xticks([0 1 2 3 4])

% Save figure (optional)
exportgraphics(gcf,"figure_tests.pdf",'BackgroundColor','white')
