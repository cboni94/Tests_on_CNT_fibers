close all
clear
clc
%==========================================================================
% PLOT and fit the stress-strain response of Nylon filaments
%==========================================================================

% Plotting settings 
set(0,'defaultTextInterpreter','latex');             % Use LaTeX for all text
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');

% Load all TSV files in current folder 
tsvFiles = dir('*.tsv');

if ~isempty(tsvFiles)
    number_of_files = length(tsvFiles);
    name = strings(number_of_files,1);

    % Display all available files
    for i = 1:number_of_files
        file = tsvFiles(i).name;
        disp([num2str(i),' ',file])
    end

    % Ask the user which test(s) to load
    sel = [4 3 2 1]; %input('Type the test number to select, or press Enter for all: ');
    if isempty(sel)
        selected_tests = 1:number_of_files;
    else
        selected_tests = sel;
    end

    % Create figure 
    figure('Units','centimeters','position',[10,10,8,5.8])
    ax1 = axes();
    hold(ax1,"on")

    % Loop through selected tests 
    for i = selected_tests
        filename = tsvFiles(i).name;
        name(i) = convertCharsToStrings(filename(1:end-4));

        % Import data (Force [N], Stroke [mm])
        t = readtable(filename,"Range","A1:D10000", ...
            "VariableNamingRule","preserve","FileType","delimitedtext");
        Force = -t(:,3).Variables;      % Negative sign to match convention
        Stroke = t(:,4).Variables;

        % Cut data at maximum force
        imax = find(Force==max(Force),1);
        Force = Force(1:imax);
        Stroke = Stroke(1:imax);

        % Extract specimen parameters from filename
        if filename(1)=='t' % twisted filament
            Gauge_Length = str2double(filename(15:end-35));
            Diameter     = 0.01*str2double(filename(33:end-18));
            filaments    = str2double(filename(38:end-13));
            Force        = Force/filaments;      % Normalize by number of filaments
            line = '-';
            col  = [200,100,100]/255;
        else                % untwisted filament
            Gauge_Length = str2double(filename(14:end-23));
            Diameter     = 0.01*str2double(filename(32:end-6));
            line = '-';
            col  = [119,172,48]/255;
        end

        % Stress-strain calculation 
        Area   = pi*Diameter^2/4;
        Strain = Stroke/Gauge_Length;
        Stress = Force/Area;

        % Polynomial fitting (5th order) 
        pol(i,:)   = polyfit(Strain,Stress,5);
        Strain_fit = linspace(0,0.2,60);
        Stress_fit(i,:) = polyval(pol(i,:),Strain_fit);

        % Correction factor using fictitious fiber area 
        R  = Diameter/2;        % fibril radius [mm]
        Rf = R*(2*2+1);         % fictitious fiber radius [mm]
        Af = pi*Rf^2;           % circumscribed (fictitious) fiber area [mm^2]
        A  = Af/19;             % fictitious fibril area [mm^2]
        k_factor = Area/A;      % correction factor (real area vs fictitious)

        % Plot experimental curve 
        plot(ax1,Strain*100,Stress*k_factor,line,"Color",col, ...
            'DisplayName',[filename(1:4),' turns'],"LineWidth",2)
        
        % (Optional) Convert elaborated tsv to xlsx
        % if filename(1)=='t'
        %     writetable(table(Strain,Force),sprintf('test_%s%s.xlsx',filename(1:11),filename(15:19)))
        % else
        %     writetable(table(Strain,Force),sprintf('test_%s%s.xlsx',filename(1:10),filename(14:18)))
        % end

    end

    % Average polynomial (example: first 4 tests, weighted) 
    selected_med = [1 2 3 4];
    pol_med = sum([pol(1,:);pol(2,:);pol(3,:);pol(4,:)*19]) ...
              /(length(selected_med)+18);

    % Plot mean fitted curve 
    plot(ax1,Strain_fit*100,polyval(pol_med,Strain_fit)*k_factor,'k--', ...
        'DisplayName','mean','MarkerIndices', 1:3:length(Strain_fit), ...
        'LineWidth',2) 

    format long
    disp(pol_med)

    % Figure formatting 
    xlabel('$\varepsilon$ (\%)')
    ylabel('$\sigma$ (MPa)')
    box('on')
    grid('off')
    xlim([0, 25])
    ylim([0, 500])
    xticks([0 5 10 15 20 25])
    lg = legend('untwisted fiber (19 filaments)','untwisted filament','','','polynomial fitting', ...
        'Location','nw','Box','off');

    exportgraphics(gcf,"figure_fitting_nylon.pdf",'BackgroundColor','white')
else
    disp('No TSV file found in the folder.');
end
