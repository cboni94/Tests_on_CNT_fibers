clear 
close all
clc
%==========================================================================
% MODEL for twisted Nylon filaments - stress-strain response
%==========================================================================
set(0,'defaultTextInterpreter','latex');
set(groot, 'DefaultAxesFontSize', 9);
set(groot, 'DefaultTextFontSize', 9);
set(groot, 'DefaultLegendFontSize', 9);
set(groot, 'DefaultColorbarFontSize', 9);
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');

% The model calculates the response of twisted nylon bundles and compares it 
% with experimental tests. Poisson effect is neglected (ν = 0).

% INPUT: number of layers in the fiber section 
layers = 2;         

% Load experimental data from twisted bundles 
xlsxFiles = dir('*.xlsx');

% Predefined colors for plots
col = [
    0.3020, 0.7451, 0.9333;  % #4DBEEE
    0.8509, 0.3254, 0.0980;  % #D95319
    0.4667, 0.6745, 0.1882;  % #77AC30
    0.9294, 0.6941, 0.1804;  % #EDB120
    0.5941, 0.2843, 0.6569;  % #7E2F8E
    0.6353, 0.0784, 0.1843;  % #A2142F
    0.0000, 0.4471, 0.7412;  % #0072BD
    1.0000, 0.0000, 0.0000;  % #FF0000
    1.0000, 0.0000, 1.0000;  % #FF00FF
    0.6314, 0.1373, 0.2706;  % #A12345
];

figure('Units','centimeters','position',[10,10,8,5.8])
ax = axes();
hold(ax,"on")
max_y_plot = 0;
max_x_plot = 0;
k = 0;

% Select tests to analyze 
sel = [2 4 3 1 5];  

for selected_tests = sel
    k = k+1;
    filename = xlsxFiles(selected_tests).name;
    
    % Import experimental test data
    test = readmatrix(filename);      
    stroke_test = test(:,1);        % stroke [mm]
    force_test  = test(:,2);        % force [N]
    
    % Zero-shift force and stroke
    stroke_test = stroke_test - stroke_test(1);            
    force_test  = force_test - force_test(1);         
    
    % Cut at maximum force
    imax = find(force_test==max(force_test),1);         
    force_test  = force_test(1:imax);                    
    stroke_test = stroke_test(1:imax);                  
    stroke_lim  = max(stroke_test);                     

    % Extract specimen parameters from filename 
    n     = str2double(filename(4:5));         % number of twists
    H     = str2double(filename(15:17));       % initial fiber length [mm]
    filaments  = str2double(filename(38:39));  % number of filaments
    D     = 0.01*str2double(filename(33:end-19));  % filament diameter [mm]

    % Geometrical data for the model 
    m   = [6 filaments-7];   % filament arrangement
    R   = D/2;               % filament radius [mm]
    A   = pi*R^2;            % filament cross-section [mm^2]
    Rf  = R*(2*layers+1);    % fiber radius [mm]
    Df  = Rf*2;              % fiber diameter [mm]
    Af  = pi*Rf^2;           % fiber cross-section [mm^2]
    phi = 2*pi*n;            % twist angle [rad]
    phiG   = phi*180/pi;     % twist angle [deg]
    theta  = phi/H;          % twist per unit length [rad/mm]
    thetaG = theta*180/pi;   % twist per unit length [deg/mm]
    
    % Display specimen information
    disp(['Filament arrangement: ',num2str(m)])
    disp(['Initial height without twist = ',num2str(H),' mm'])
    disp(['Fiber diameter = ',num2str(Df),' mm'])
    disp(['Filament diameter = ',num2str(D),' mm'])
    disp(['Unit twist angle = ',num2str(thetaG),' deg/mm'])
    
    % Input stress-strain curve (polynomial fit of single filament test) 
    pp = 1e6*[2.4702 -1.6240 0.3982 -0.0328 0.0023 0.0000]; % 5th-order fit
    for i = 1:length(pp)
        pol(i) = A*pp(i)/((H)^(length(pp)-i));
    end
    stroke_inp = linspace(0,stroke_lim,100);      
    force_inp  = polyval(pol,stroke_inp);               
    force_lim  = max(force_inp);                      

    % Initial Helix angles for each layer 
    r = zeros(1,layers);
    alpha = zeros(1,layers);
    for lr=1:layers
        r(lr)     = 2*lr*R;
        alpha(lr) = atan(H/(2*pi*r(lr)*n));                    
    end
    
    % New fiber height after twisting 
    l_last_layer = H;          
    H_new = sqrt(l_last_layer^2-(2*pi*r(end)*n)^2);  
    alpha_max   = atan(H_new/(2*pi*Rf*n));
    alphaG_max  = alpha_max*180/pi;
    disp(['Surface helix angle = ',num2str(alphaG_max),' deg'])
    
    % Elongation of filaments after twisting 
    dH = linspace(0,max(stroke_inp),100);   % fiber elongation range
    stroke  = zeros(length(dH),layers);    
    alphaP  = zeros(length(dH),layers);    
    stroke0 = dH+H_new-H;                  
    for lr=1:layers
        for i=1:length(dH)                   
            alphaP(i,lr) = atan((dH(i)+H_new)/(2*pi*r(lr)*n));
            stroke(i,lr) = sqrt((dH(i)+H_new)^2+(2*pi*r(lr)*n)^2)-H;
        end 
    end
    alphaPG = alphaP*180/pi;   
    
    % Axial force for central filament 
    force0 = zeros(length(dH),1);
    for i=1:length(stroke0)
        if stroke0(i)>0
            force0(i) = polyval(pol,stroke0(i));    
        else
            force0(i) = 0;
        end
    end
    
    % Axial force for twisted filaments 
    force = zeros(length(dH),layers);
    for lr=1:layers
        for i=1:length(stroke)
            if stroke(i,lr)>0
                force(i,lr) = polyval(pol,stroke(i,lr));                
            else
                force(i,lr) = 0;
            end
        end
    end
    
    % Total bundle force (model) 
    F0 = force0;                
    F  = force.*sin(alphaP);    
    F_TOT = F0;
    for lr=1:layers
        F_TOT = F_TOT + m(lr).*F(:,lr);      
    end
    
    % Stress-strain curves 
    stress_test = force_test/Af;
    strain_test = stroke_test/H_new;
    stress_mod  = F_TOT/Af;
    strain_mod  = dH/H_new;
    stress_inp  = force_inp/A;
    strain_inp  = stroke_inp/H;
    
    % Plot curves 
    plot(ax,strain_test*100,stress_test,"Color",col(selected_tests,:), ...
        'DisplayName',[filename(38:39),' wires',sprintf(' - %d°/mm ',round(thetaG))], ...
        'LineWidth',2) % experimental curve
    mp = plot(ax,strain_mod*100,stress_mod,'k--','LineWidth',2); % model curve
    mp.Annotation.LegendInformation.IconDisplayStyle = 'off'; % hide duplicate legend
    
    if max(strain_test)> max_x_plot
        max_x_plot = max(strain_test);
    end
    if max(stress_test)>max_y_plot
        max_y_plot = max(stress_test);
    end
    lg{k} = ['$\tau$ = ',sprintf('%1.2f ',theta),' rad/mm']; 
end

% Legend and formatting 
plot(0,0,'k--','DisplayName','respective models',LineWidth=2)
leg = legend(ax,lg{1},lg{2},lg{3},lg{4},lg{5},'respective models','Location','nw','Box','off');
set(leg, 'ItemTokenSize', [20, 10]);  
xlabel('$\varepsilon_f$ (\%)')
ylabel('$\sigma_f$ (GPa)')
box(ax,'on')
grid(ax,'off')
ylim(ax,[0, 500])
xlim(ax,[0, 25])
xticks([0 5 10 15 20 25])
exportgraphics(gcf,"figure_nylon_fiber.pdf",'BackgroundColor','white')
